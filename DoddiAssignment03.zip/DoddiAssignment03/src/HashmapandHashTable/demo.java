package HashmapandHashTable;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //----------hashtable -------------------------
        Hashtable<Integer,String> hashtable = new Hashtable<Integer,String>();
        hashtable.put(101," ajay");
        hashtable.put(101,"Vijay");
        hashtable.put(102,"Ravi");
        System.out.println("-------------Hash table--------------");
        for (Map.Entry m:hashtable.entrySet()) {
            System.out.println(m.getKey()+" "+m.getValue());
        }
 
        //----------------hashmap--------------------------------
        HashMap<Integer,String> hashmap = new HashMap<Integer,String>();
        hashmap.put(100,"Amit");
        hashmap.put(104,"Amit"); 
        hashmap.put(101,"Vijay");
        System.out.println("-----------Hash map-----------");
        for (Map.Entry m:hashmap.entrySet()) {
            System.out.println(m.getKey()+" "+m.getValue());
        }

	}

}
