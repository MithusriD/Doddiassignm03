package diffcreatingthread;

public class impRunnableinterface implements Runnable  {

	public void run() {
		System.out.println("it is started");
	}

	public static void main(String args[]) {
		impRunnableinterface interf = new impRunnableinterface();
		Thread thread = new Thread(interf);
		thread.start();
	}

}
