package diffcreatingthread;

public class extendsthreadclass extends Thread{

	public void run()
	 {
	  System.out.println("helloo thread is started..");
	 }
	 public static void main( String args[] )
	 {
		 extendsthreadclass thread = new  extendsthreadclass();
		 thread.start();
	 }

}
