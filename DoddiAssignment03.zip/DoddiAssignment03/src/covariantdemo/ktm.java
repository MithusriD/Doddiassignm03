package covariantdemo;

public class ktm extends Bike{
	// Covariant return type in action!!!
	public ktm getInstance() {
	return this;
	}
	public void move() {
	System.out.println("ktm is a crazy bike ...");
	}

}
