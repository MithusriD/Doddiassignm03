package covariantdemo;

public class Bike {
	public Bike getInstance() {
		return this;
		}

}
