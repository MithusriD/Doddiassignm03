package covariantdemo;

public class CovariantTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ktm().getInstance().move();

	}

}
