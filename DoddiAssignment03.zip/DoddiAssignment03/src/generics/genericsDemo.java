package generics;


public class genericsDemo {

	public static void main(String[] args) {
		 //we are going to create genericsClass object with String as type parameter
		genericsClass<String> sgs = new genericsClass<String>("JAVA2NOVICE");
        sgs.printType();
        //we are going to create genericsClass object with Boolean as type parameter
        genericsClass<Boolean> sgb = new genericsClass<Boolean>(Boolean.TRUE);
        sgb.printType();
		

	}
}
