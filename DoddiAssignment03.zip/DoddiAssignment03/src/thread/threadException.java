package thread;

public class threadException extends Thread{  
	 public void run(){  
	   System.out.println("running...");  
	 }  
	 public static void main(String args[]){  
		 threadException t1=new threadException();  
	  t1.start();  
	  t1.start();  
	 }  
	}  

