package StringBuilderBufferandclass;

public class StringClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=new String ("Teckpix");
		str.concat("Solution");
		System.out.println(str);

	}

}
