package StringBuilderBufferandclass;

public class StringBufferExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 StringBuffer buffer = new StringBuffer("Hi");
	      buffer.append("Java 8");
	      System.out.println("StringBufferExample" +buffer);

	}

}
