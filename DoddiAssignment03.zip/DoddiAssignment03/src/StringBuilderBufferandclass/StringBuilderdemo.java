package StringBuilderBufferandclass;

public class StringBuilderdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 StringBuilder build =new StringBuilder("Hello");
	      build.append("Java 8");
	      System.out.println("StringBuilderExample" +build);

	}

}
