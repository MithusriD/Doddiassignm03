package java8features;

import java.util.Optional;

public class Optionalmeth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] str = new String[10]; 
        Optional<String> ing = Optional.ofNullable(str[5]); 
        if (ing.isPresent()) { 
            String word = str[5].toLowerCase(); 
            System.out.print(str); 
         } else
           System.out.println("string is null"); 

	}

}
