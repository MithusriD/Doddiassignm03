package java8features;

public class Lambdaexpression {
	interface MyFunctionalInterface {

		//A method with no parameter
	    public String sayHello();
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // lambda expression
		MyFunctionalInterface msg = () -> {
    		return "Hello";
    	};
        System.out.println(msg.sayHello());


	}

}
