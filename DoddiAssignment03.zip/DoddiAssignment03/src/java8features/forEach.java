package java8features;

import java.util.ArrayList;
import java.util.List;

public class forEach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> subList = new ArrayList<String>();
        subList.add("banana");
        subList.add("rasbeery");
        subList.add("carrot");
        subList.add("apple");
        subList.add("mango");
        System.out.println("------------ List--------------");
        subList.forEach(sub -> System.out.println(sub));

	}

}
