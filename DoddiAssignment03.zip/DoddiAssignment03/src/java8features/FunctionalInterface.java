package java8features;

public interface FunctionalInterface {
	 public void firstInt_method();
	 
	    @Override
	    public String toString(); //Overridden from Object class
	 
	    @Override
	    public boolean equals(Object obj); //Overridden from Object class
	}


