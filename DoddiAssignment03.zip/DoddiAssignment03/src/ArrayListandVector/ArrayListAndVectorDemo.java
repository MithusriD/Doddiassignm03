package ArrayListandVector;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class ArrayListAndVectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // creating an ArrayList
        ArrayList<String> arr = new ArrayList<String>();
 
        // adding object to arraylist
        arr.add("Practice.GeeksforGeeks.org");
        arr.add("quiz.GeeksforGeeks.org");
        arr.add("code.GeeksforGeeks.org");
        arr.add("contribute.GeeksforGeeks.org");
 
        // traversing elements using Iterator'
        System.out.println("ArrayList elements are:");
        Iterator it = arr.iterator();
        while (it.hasNext())
            System.out.println(it.next());
 
        // creating Vector
        Vector<String> vector = new Vector<String>();
        vector.addElement("Practice");
        vector.addElement("quiz");
        vector.addElement("code");

        // traversing elements using Enumeration
        System.out.println("\nVector elements are:");
        Enumeration enu = vector.elements();
        while (enu.hasMoreElements())
            System.out.println(enu.nextElement());

	}

}
