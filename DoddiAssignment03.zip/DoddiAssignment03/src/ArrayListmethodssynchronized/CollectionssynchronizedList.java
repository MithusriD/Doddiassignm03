package ArrayListmethodssynchronized;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class CollectionssynchronizedList {
	public static void main(String[] args) 
	{ 
	// Create an ArrayList object with initial capacity of 10. 
	// Non-synchronized ArrayList Object. 
	   List<String> str1 = new ArrayList<String>(); 

	// Add elements in the list. 
	   str1.add("Apple"); 
	   str1.add("Orange"); 
	   str1.add("Banana"); 
	   str1.add("Pineapple"); 
	   str1.add("Guava"); 

	// Synchronizing ArrayList in Java. 
	   List<String> list = Collections.synchronizedList( str1 ); // l is non-synchronized. 

	// Here, we will use a synchronized block to avoid the non-deterministic behavior. 
	   synchronized(list) 
	   { 
	// Call iterator() method to iterate the ArrayList. 
	    Iterator<String> itr = list.iterator(); 
	    while(itr.hasNext())
	    { 
	      String str = itr.next(); 
	      System.out.println(str); 
	    } 
	  } 
	 } 

}
