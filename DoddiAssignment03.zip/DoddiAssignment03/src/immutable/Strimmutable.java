package immutable;

public class Strimmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String str1 = "hello";
		 str1.concat("world");
	 
	        // Yes, s1 still refers to "java"
	        System.out.println("str1 refers to " + str1);

	}

}
