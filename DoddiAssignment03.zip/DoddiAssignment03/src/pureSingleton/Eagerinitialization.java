package pureSingleton;

public class Eagerinitialization {
	private static volatile Eagerinitialization instance = new Eagerinitialization();
		  //private constructor.
		  private Eagerinitialization() {
		  }
		  public static Eagerinitialization getInstance() {
		    return instance;
		  }

}
