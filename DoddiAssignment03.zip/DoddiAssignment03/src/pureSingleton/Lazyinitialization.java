package pureSingleton;

public class Lazyinitialization {
	private static Lazyinitialization instance;
	  private Lazyinitialization() {
	  }  //private constructor.
	  public static Lazyinitialization getInstance() {
	    if (instance == null) {
	      //if there is no instance available... create new one
	      instance = new Lazyinitialization();
	    }
	    return instance;
	  }
}
