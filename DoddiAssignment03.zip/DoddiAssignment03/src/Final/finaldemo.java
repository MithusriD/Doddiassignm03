package Final;

public class finaldemo {
	 //declaring final variable  
    int age = 18;  
    void display() {  
      
    // reassigning value to age variable   
    // gives compile time error  
    age = 55;  
    }  


}
