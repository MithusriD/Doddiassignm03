package Final;

public class FinalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		finaldemo obj = new finaldemo();
		
		
	    //gives compile time error  
	    obj.display();  
	    }  

	}


