package throwsclause;

public class SuperClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SuperClass x = new subclass();
		  // x.method();
		  // x.msg();

	}

}
