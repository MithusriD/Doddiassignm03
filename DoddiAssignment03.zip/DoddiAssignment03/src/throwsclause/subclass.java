package throwsclause;

import java.io.IOException;

public class subclass extends SuperClass{

/*
* void method() throws IOException { System.out.println("SubClass");//Throws an
* error for IOException }
*/
      void msg() throws ArithmeticException {
      System.out.println("Hello");
}

}