package TryWithResources;

import java.io.FileOutputStream;

public class TryWithResourcesdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(FileOutputStream fileOutputStream =new FileOutputStream("java.txt")){      
			String str = "Welcome to javaTpoint!";      
			byte byteArray[] = str.getBytes(); //converting string into byte array      
			fileOutputStream.write(byteArray);  
			System.out.println("Message written to file successfuly!");      
			}
		catch(Exception exception){  
			       System.out.println(exception);  
			}      

	}

}
