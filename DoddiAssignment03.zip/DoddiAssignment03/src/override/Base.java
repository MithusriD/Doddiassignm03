package override;

public class Base {
	 public void fun() {
	     System.out.println("Base fun");    
	  }
}