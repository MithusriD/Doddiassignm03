package override;

public class Derived extends Base {

	 public void fun() {  // overrides the Base's fun()
	     System.out.println("Derived fun");  

}
}